package com.postits.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int TEXT_DARK = 0xFF212121;

    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        if (savedInstanceState == null
                && Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        render();
        Notifier.sync(this);

        if (savedInstanceState == null) handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render();
        handleIntent(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Notifier.sync(this);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        if (i.getBooleanExtra("new", false)) {
            i.removeExtra("new");
            showEditor(null);
        } else if (i.hasExtra("note_id")) {
            long id = i.getLongExtra("note_id", -1L);
            i.removeExtra("note_id");
            NoteStore.Note n = NoteStore.find(this, id);
            if (n != null) showEditor(n);
        }
    }

    // ---------------------------------------------------------------- UI

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        TextView title = new TextView(this);
        title.setText("Post-its");
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TEXT_DARK);
        title.setPadding(dp(20), dp(24), dp(20), dp(8));
        root.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(4), 0, dp(12));
        scroll.addView(list, new ViewGroup.LayoutParams(MATCH, WRAP));
        root.addView(scroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        Button add = new Button(this);
        add.setText("+ Nueva nota");
        add.setOnClickListener(v -> showEditor(null));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(MATCH, WRAP);
        ap.setMargins(dp(16), dp(8), dp(16), dp(16));
        root.addView(add, ap);

        return root;
    }

    private void render() {
        list.removeAllViews();
        List<NoteStore.Note> notes = NoteStore.load(this);

        if (notes.isEmpty()) {
            TextView hint = new TextView(this);
            hint.setText("Aún no tienes notas.\nToca \"+ Nueva nota\" para crear la primera.");
            hint.setTextSize(16);
            hint.setTextColor(0xFF757575);
            hint.setPadding(dp(20), dp(24), dp(20), dp(24));
            list.addView(hint);
            return;
        }
        for (NoteStore.Note n : notes) {
            list.addView(card(n));
        }
    }

    private View card(final NoteStore.Note n) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(n.color);
        bg.setCornerRadius(dp(10));
        card.setBackground(bg);
        card.setElevation(dp(3));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        card.setLayoutParams(lp);

        TextView text = new TextView(this);
        text.setText(n.text);
        text.setTextSize(18);
        text.setTextColor(TEXT_DARK);
        card.addView(text, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END);

        TextView pin = action(n.pinned ? "Quitar de bloqueo" : "Fijar en bloqueo");
        pin.setOnClickListener(v -> {
            n.pinned = !n.pinned;
            NoteStore.upsert(this, n);
            afterChange();
        });
        row.addView(pin);

        TextView del = action("Borrar");
        del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("¿Borrar esta nota?")
                .setPositiveButton("Borrar", (d, w) -> {
                    NoteStore.delete(this, n.id);
                    afterChange();
                })
                .setNegativeButton("Cancelar", null)
                .show());
        row.addView(del);

        card.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
        card.setOnClickListener(v -> showEditor(n));
        return card;
    }

    private TextView action(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(13);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(0xFF5D4037);
        t.setPadding(dp(10), dp(10), dp(10), dp(10));
        return t;
    }

    // ------------------------------------------------------------ editor

    private void showEditor(final NoteStore.Note existing) {
        final boolean isNew = existing == null;
        final NoteStore.Note n = isNew ? NoteStore.newNote() : existing;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText input = new EditText(this);
        input.setHint("Escribe tu nota…");
        input.setText(n.text);
        input.setMinLines(3);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(input, new LinearLayout.LayoutParams(MATCH, WRAP));

        final int[] chosen = {n.color};
        final List<View> dots = new ArrayList<>();
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        for (final int col : NoteStore.COLORS) {
            View dot = new View(this);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(36), dp(36));
            p.setMargins(0, dp(14), dp(10), dp(6));
            dot.setOnClickListener(v -> {
                chosen[0] = col;
                paintDots(dots, chosen[0]);
            });
            colors.addView(dot, p);
            dots.add(dot);
        }
        paintDots(dots, chosen[0]);
        box.addView(colors, new LinearLayout.LayoutParams(MATCH, WRAP));

        final CheckBox pin = new CheckBox(this);
        pin.setText("Mostrar en la pantalla de bloqueo");
        pin.setChecked(n.pinned);
        box.addView(pin, new LinearLayout.LayoutParams(MATCH, WRAP));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isNew ? "Nueva nota" : "Editar nota")
                .setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    String text = input.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "La nota está vacía", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    n.text = text;
                    n.color = chosen[0];
                    n.pinned = pin.isChecked();
                    NoteStore.upsert(this, n);
                    afterChange();
                })
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dialog.show();
    }

    private void paintDots(List<View> dots, int selected) {
        for (int i = 0; i < dots.size(); i++) {
            int c = NoteStore.COLORS[i];
            boolean on = c == selected;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(c);
            g.setStroke(dp(on ? 3 : 1), on ? 0xFF424242 : 0x33000000);
            dots.get(i).setBackground(g);
        }
    }

    // ----------------------------------------------------------- helpers

    private void afterChange() {
        Notifier.sync(this);
        PostItWidget.refresh(this);
        render();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
