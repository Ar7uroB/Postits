package com.postits.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/**
 * Publica las notas "fijadas" como notificaciones persistentes con visibilidad
 * pública, que es la forma en que Android las muestra en la pantalla de bloqueo.
 */
public final class Notifier {

    private static final String CHANNEL = "postits_fijados";

    private Notifier() {}

    public static void sync(Context context) {
        Context app = context.getApplicationContext();
        NotificationManager nm = app.getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Post-its fijados", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Notas fijadas en la pantalla de bloqueo");
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        nm.cancelAll();

        for (NoteStore.Note n : NoteStore.load(app)) {
            if (!n.pinned || n.text.trim().isEmpty()) continue;

            int notifId = (int) (n.id & 0x7fffffffL);

            Intent open = new Intent(app, MainActivity.class);
            open.putExtra("note_id", n.id);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                    app, notifId, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            Notification notification = new Notification.Builder(app, CHANNEL)
                    .setSmallIcon(R.drawable.ic_note)
                    .setContentTitle("Post-it")
                    .setContentText(n.text)
                    .setStyle(new Notification.BigTextStyle().bigText(n.text))
                    .setColor(n.color)
                    .setCategory(Notification.CATEGORY_REMINDER)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(false)
                    .setContentIntent(pi)
                    .build();

            nm.notify(notifId, notification);
        }
    }
}
