package com.postits.app;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.List;

public class WidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    private static final class Factory implements RemoteViewsFactory {
        private final Context context;
        private List<NoteStore.Note> notes = new ArrayList<>();

        Factory(Context context) {
            this.context = context;
        }

        @Override public void onCreate() {
            notes = NoteStore.load(context);
        }

        @Override public void onDataSetChanged() {
            notes = NoteStore.load(context);
        }

        @Override public void onDestroy() {
            notes.clear();
        }

        @Override public int getCount() {
            return notes.size();
        }

        @Override public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= notes.size()) return null;
            NoteStore.Note n = notes.get(position);

            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_item);
            rv.setTextViewText(R.id.item_text, n.text);
            rv.setInt(R.id.item_root, "setBackgroundColor", n.color);

            Intent fillIn = new Intent();
            fillIn.putExtra("note_id", n.id);
            rv.setOnClickFillInIntent(R.id.item_root, fillIn);
            return rv;
        }

        @Override public RemoteViews getLoadingView() {
            return null;
        }

        @Override public int getViewTypeCount() {
            return 1;
        }

        @Override public long getItemId(int position) {
            return position < notes.size() ? notes.get(position).id : position;
        }

        @Override public boolean hasStableIds() {
            return true;
        }
    }
}
