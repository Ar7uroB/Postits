package com.postits.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Vuelve a publicar los post-its fijados después de reiniciar o actualizar la app. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Notifier.sync(context);
        PostItWidget.refresh(context);
    }
}
