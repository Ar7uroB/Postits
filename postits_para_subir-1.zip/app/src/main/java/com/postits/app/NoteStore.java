package com.postits.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Guarda las notas como JSON en SharedPreferences. */
public final class NoteStore {

    public static final int[] COLORS = {
            0xFFFFF59D, // amarillo
            0xFFF8BBD0, // rosa
            0xFFC8E6C9, // verde
            0xFFBBDEFB, // azul
            0xFFFFCC80  // naranja
    };

    private static final String PREFS = "postits";
    private static final String KEY = "notes";

    public static final class Note {
        public long id;
        public String text = "";
        public int color = COLORS[0];
        public boolean pinned;
    }

    private NoteStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static Note newNote() {
        Note n = new Note();
        n.id = System.currentTimeMillis();
        return n;
    }

    public static synchronized List<Note> load(Context c) {
        List<Note> out = new ArrayList<>();
        String raw = prefs(c).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Note n = new Note();
                n.id = o.getLong("id");
                n.text = o.optString("text", "");
                n.color = o.optInt("color", COLORS[0]);
                n.pinned = o.optBoolean("pinned", false);
                out.add(n);
            }
        } catch (Exception ignored) {
            // si el JSON está dañado, se empieza con lista vacía
        }
        return out;
    }

    public static synchronized void save(Context c, List<Note> notes) {
        JSONArray arr = new JSONArray();
        try {
            for (Note n : notes) {
                JSONObject o = new JSONObject();
                o.put("id", n.id);
                o.put("text", n.text);
                o.put("color", n.color);
                o.put("pinned", n.pinned);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }

    public static synchronized Note find(Context c, long id) {
        for (Note n : load(c)) {
            if (n.id == id) return n;
        }
        return null;
    }

    /** Inserta la nota o reemplaza la que tenga el mismo id. */
    public static synchronized void upsert(Context c, Note note) {
        List<Note> notes = load(c);
        boolean replaced = false;
        for (int i = 0; i < notes.size(); i++) {
            if (notes.get(i).id == note.id) {
                notes.set(i, note);
                replaced = true;
                break;
            }
        }
        if (!replaced) notes.add(0, note);
        save(c, notes);
    }

    public static synchronized void delete(Context c, long id) {
        List<Note> notes = load(c);
        for (int i = 0; i < notes.size(); i++) {
            if (notes.get(i).id == id) {
                notes.remove(i);
                break;
            }
        }
        save(c, notes);
    }
}
