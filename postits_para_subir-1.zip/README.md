# Post-its (Android)

Notas tipo post-it que puedes poner en la pantalla principal (widget) y en la
pantalla de bloqueo (notificación fija).

## Obtener el APK con GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub (privado o público).
2. Sube TODO el contenido de esta carpeta, incluida la carpeta oculta `.github`.
3. Entra a la pestaña **Actions** del repositorio. Se ejecuta solo "Compilar APK"
   (o ábrelo y toca **Run workflow**).
4. Cuando termine (unos 3-5 minutos), abre la ejecución y baja el archivo
   **postits-apk** de la sección *Artifacts*. Es un .zip con `app-debug.apk` adentro.
5. Pasa el APK al celular e instálalo (Android te pedirá permitir instalar apps
   de esta fuente).

## Usar la app

- **+ Nueva nota**: escribe, elige color y, si quieres, marca
  "Mostrar en la pantalla de bloqueo".
- **Widget**: mantén presionada la pantalla principal > Widgets > Post-its.
  Tocar una nota la abre para editarla; el botón + crea una nueva.
- **Pantalla de bloqueo**: las notas fijadas aparecen como notificaciones.
  Acepta el permiso de notificaciones la primera vez. Si no se ven en el
  bloqueo, en Ajustes > Notificaciones > Pantalla de bloqueo elige
  "Mostrar todo el contenido de las notificaciones".

## Compilar con Android Studio (alternativa)

Abre la carpeta como proyecto y ejecuta *Build > Build APK(s)*.
